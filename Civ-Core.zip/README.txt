This resource pack, and it's assets were made by TwistedDreams#0001
I want to thank you for purchasing my product, if you have any suggestions, commission requests or issues then please do not hesitate to reach out to me.


This pack can easily be added to your own, please note that this will change the inventory texture or ALL player heads/skulls.

Included in this zip file are:
 - 2D Player Head .json file.
